
export type LocalStorage = {
  key: string;
  value: any ;
};
