import { useCargarCarrito } from "../../hooks/useCargarCarrito";

const BarraPaginaCarrito = () => {
  const { carrito } = useCargarCarrito();

  return (
    <div className="bg-green-500 h-14 sticky bottom-0 flex gap-3 items-center justify-center font-semibold">
      <a href="#pago">Pago</a>
      <a
        href="#productos"
        className="bg-[#FFC20E] rounded-xl size-10 flex justify-center items-center"
      >
        <img className="size-8" src="/svg/Cart.svg" alt="Carrito" />
      </a>
      <a href="#entrega"> Entrega</a>
    </div>
  );
};

export default BarraPaginaCarrito;
