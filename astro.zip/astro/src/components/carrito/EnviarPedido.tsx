const EnviarPedido = () => {
  return (
    <button
      type="submit"
      className="bg-green-500 rounded-xl text-white font-bold p-2 m-2 mx-10 cursor-pointer"
    >
      Enviar Pedido
    </button>
  );
};

export default EnviarPedido;
